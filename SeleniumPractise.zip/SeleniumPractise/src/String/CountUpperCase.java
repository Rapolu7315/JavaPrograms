package String;

public class CountUpperCase {

	public static void main(String[] args) {
		
		String st = "I am Automation Tester";
		int count = 0;
		
		System.out.println("The given string is: "+st);
		
		for(int i=0;i<st.length();i++) {
			char ch = st.charAt(i);
			
			if(Character.isUpperCase(ch)) {
			  count++;
			}
			System.out.println("count the numer of uppercases: "+count);
		}

	}

}
