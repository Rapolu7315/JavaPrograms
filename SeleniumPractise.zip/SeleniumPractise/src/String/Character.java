package String;

public class Character {

	public static void main(String[] args) {
		
		String s = "I am Automation Tester";
		System.out.println("the Length of the given string: "+s);
		
		for(int i=0;i<s.length();i++) {
			char ch = s.charAt(i);
			System.out.println("the given character of the string is: "+ch);
		}
	
	}

	}


