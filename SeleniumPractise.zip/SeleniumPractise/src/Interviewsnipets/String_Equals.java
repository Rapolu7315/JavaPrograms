package Interviewsnipets;

public class String_Equals {

	public static void main(String[] args) {
		String st = "Venkatesh";
		String st1 = "rapolu";
		System.out.println(st==st1);
		
	}

}
