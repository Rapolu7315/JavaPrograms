package Interviewsnipets;

public class classA {
	static int a = 100;
	int b= 200;
	
	public static void methodA() {
		a = 10;
		//int b= 20;//new
		System.out.println("a: "+a);
		//System.out.println("b: "+b);//Non static variable can not be accessed in static methods
	}
public  void methodB() {
	a = 10;
	b= 20;
	System.out.println("a: "+a);//Non static methods can access the static variables and non static variables.
		System.out.println("b: "+b);
	}
public static void main(String[] args) {
	System.out.println("a: "+a);
	//System.out.println("b: "+b);
	classA c1 = new classA();
	System.out.println("a: "+a);
	//System.out.println("b: "+b);
	c1.methodB();
	classA.methodA();
}
}
