package Practice;

public class Palindrrome {

	public static void main(String[] args) {
		String actual = "madam";
		String rev = "";
		
		System.out.println("the actual string : "+actual);
		
		for(int i=0;i<actual.length();i++)
		{
			rev = actual.charAt(i)+rev;
			
		}
             System.out.println("The reverse string: "+rev);
             
             if(actual.equalsIgnoreCase(rev))
             {
            	 System.out.println("given string is pallindrome");
             }else
             {
            	 System.out.println("given string is not pallindrome."
            	 		+ "");
             }
	}

}
