package Practice;

import java.util.concurrent.TimeUnit;

import org.apache.bcel.generic.Select;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Dropdown {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
	      WebDriver driver = new ChromeDriver();
	      
	      driver.manage().window().maximize();
	      driver.manage().deleteAllCookies();
	      driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	      driver.get("https://google.com");
	      
	      driver.get("https://artoftesting.com/samplesiteforselenium");
	      
	      WebElement dropdown = driver.findElement(By.id("testingDropdown"));
	      org.openqa.selenium.support.ui.Select select = new org.openqa.selenium.support.ui.Select(dropdown);
	      select.selectByIndex(1);
	      
	      WebElement dropdown1 = driver.findElement(By.id("testingDropdown"));
	      org.openqa.selenium.support.ui.Select select1 = new org.openqa.selenium.support.ui.Select(dropdown1);
	      select1.selectByVisibleText("Automation Testing");
	      

	}

}
