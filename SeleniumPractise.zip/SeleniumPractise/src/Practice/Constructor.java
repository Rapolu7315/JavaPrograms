package Practice;



public class Constructor {
	
	/*String name, clgname;
	int salary;
    int annualsalary;
    
    public Constructor(String name, int salary, int annualsalary) {
    	this.name = name;
    	this.annualsalary = annualsalary;
    	this.salary = salary;
    	
    	
    }
    public Constructor(String name, String clgname, int salary, int annualsalary) {
    	this.name = name;
    	this.annualsalary = annualsalary;
    	this.salary = salary;
    	this.clgname = clgname;
    	
    }
    
    public void details()
    {
    	System.out.println("Name :"+name);
    	System.out.println("Salary :"+salary);
    	System.out.println("Annaul Salary :"+annualsalary);
    	System.out.println("College Name : "+clgname);
    }
	
   public static void main(String args[]) {
	   Constructor c1 = new Constructor("Venkatesh", "KLUniverity", 50000, 700000);
	   c1.details();*/
	
	String schoolname, studentname;
	String subject;
	int id, rollnumber;
	
	public Constructor(String schoolname, String studentname, int id, int rollnumber) {
		this.schoolname = "Kannna English medium school";
		this.studentname = "Venkatesh";
		this.rollnumber = 24;
		this.id = 7315;
		
	}
	
	public Constructor(String schoolname, String studentname, int id, int rollnumber, String subject) {
		this.schoolname = schoolname;
		this.studentname = studentname;
		this.rollnumber = rollnumber;
		this.id = id;
		this.subject= subject;
		
	}
	
	public void details() {
		System.out.println("Name: "+studentname);
		System.out.println("SchoolName: "+schoolname);
		System.out.println("Rollnumber: "+rollnumber);
		System.out.println("ID: "+id);
		System.out.println("Subject: "+subject);
	}
	
	public static void main(String[] args) {
		Constructor c1 = new Constructor("Kanna English medium school", "Venkatesh", 7315, 24);
				c1.details();
				Constructor c2 = new Constructor("Kanna English medium school", "Venkatesh", 7315, 24, "Maths");
				c2.details();
	}
	
	   
			   
	   
   }
	
	 
	

		
		
	


