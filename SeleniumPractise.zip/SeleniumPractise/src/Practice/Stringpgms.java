package Practice;

public class Stringpgms {

	public static void main(String args[]) {
		String str = "Yedoo okaraagam pilichindii velaaa";
		/*
		 * int count =0;
		 * 
		 * System.out.println("Length of String : "+str.length());
		 * 
		 * for(int i = 0; i<str.length();i++) { //count++; for(int j=i+1;
		 * j<str.length();j++) {
		 * 
		 * if (str.charAt(i)==str.charAt(j)) { count++;
		 * System.out.println("String character printed is : "+str.charAt(i));
		 * System.out.println("And Character printed count is : "+count); }
		 * 
		 * 
		 * 
		 * 
		 * }
		 * 
		 * count =0;
		 * 
		 * }
		 */
		String str1 = "";
		for (int i = 0; i < str.length(); i++) {
			int count = 0;
			for (int j = 0; j < str.length(); j++) {
				
				if (str.charAt(i) == str.charAt(j) && i != j) {
					count = 1;
					break;
				}
			}
			if (count == 0)
				System.out.print(str.charAt(i));
		}

	}
}
