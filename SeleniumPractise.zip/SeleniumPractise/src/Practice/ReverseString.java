package Practice;

public class ReverseString {
	
	
     
   
    public static void main (String[] args)
    {
        int arr[] = {6, 10, 5, 4, 9, 120, 4, 6, 10};
        int n = arr.length;
        printDistinct(arr, n);
    }
	/*
	 * public static void main(String[] args) {
	 * 
	 * String sr = "madam"; String rev = ""; StringBuilder unq = new
	 * StringBuilder(); int count =0;
	 * 
	 * 
	 * System.out.println("the actual string : "+sr);
	 * System.out.println("the length of the string :"+sr.length());
	 * 
	 * for(int i=0;i<sr.length();i++) { for(int j=i+1;j<=i;j++) {
	 * if(sr.charAt(i)==sr.charAt(j)) { count++; }else {
	 * unq=unq.append(sr.charAt(i));
	 * 
	 * } }
	 * 
	 * 
	 * } System.out.println(unq);
	 * System.out.println("count the number of character of a:"+count);
	 * 
	 * 
	 * 
	 * for(int i=0; i<sr.length();i++) { rev = sr.charAt(i)+rev;
	 * 
	 * } System.out.println("the reverse string :"+rev);
	 * 
	 * if(sr.equalsIgnoreCase(rev)) { System.out.println("the string is palindram");
	 * }else { System.out.println("the string is not palindram"); } }
	 */

}