package Practice;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Calender {

	public static void main(String[] args) {

	      System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
	      WebDriver driver = new ChromeDriver();
	      
	      driver.manage().window().maximize();
	      driver.manage().deleteAllCookies();
	      driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	      driver.get("https://google.com");
	      
	      driver.get("https://www.redbus.in/");
	      
	      String date = "21";
	      String month = "July";
	      String year= "2023";
	      
	      driver.findElement(By.xpath("//*[@class='dateText']")).click();
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	      
	}

    
}
