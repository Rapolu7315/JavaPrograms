package Practice;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CheckBoxMethod2 {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
	      WebDriver driver = new ChromeDriver();
	      
	      driver.manage().window().maximize();
	      driver.manage().deleteAllCookies();
	      driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	      driver.get("https://google.com");
	      driver.get("https://artoftesting.com/samplesiteforselenium");
	      
	     WebElement checkbox = driver.findElement(By.xpath("//*[@class='Automation']"));
	     boolean isdisplayed = checkbox.isDisplayed();
	     if(isdisplayed==true) {
	    	 checkbox.click();
	     }
	     
	      
	      
	      
	      
	      
	      
	      
	      
	      
	}

}
