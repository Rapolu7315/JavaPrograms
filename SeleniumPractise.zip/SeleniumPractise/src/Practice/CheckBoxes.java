package Practice;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CheckBoxes {

	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
	      WebDriver driver = new ChromeDriver();
	      
	      driver.manage().window().maximize();
	      driver.manage().deleteAllCookies();
	      driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	      driver.get("https://google.com");
	      driver.get("https://artoftesting.com/samplesiteforselenium");
	      
	      //1. Select specific check box by using Is Selected()
	      
	      WebElement checkbox = driver.findElement(By.xpath("//*[@class='Automation']"));
	      boolean Isselected = checkbox.isSelected();
	      
	      if(Isselected == false) {
	    	  checkbox.click();
	      }
	      
	      
	      
	      //2.Select all checkboxes
	      
	  /*  List<WebElement>  checkboxes = driver.findElements(By.xpath("(//form[@action='#'])[2]"));
	    System.out.println("Total number of check boxes: "+checkboxes.size());
	    
	    //Using for loop
	    for(int i=0;i<checkboxes.size();i++)
	    {
	    	checkboxes.get(i).click();
	    }*/
}
}
